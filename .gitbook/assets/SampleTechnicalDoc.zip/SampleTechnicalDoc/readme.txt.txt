Markdown Editor : Visual Studio 1.64.2
Plugin markdown to pdf : https://marketplace.visualstudio.com/items?itemName=yzane.markdown-pdf

