# Sample technical documentation

* Authors : XX && YY
* Version : [Date of last update]

## How to

* Prerequisites for all "How to" Use Case
    * Active session on AWS Console
    * Be on the correct region (eu-south-1)

---

### How to find [Use Case description]

1. Sample with Image ([Source sample](https://aws.amazon.com/vpc/features/))

![GoToVpc](./img/SelectVPC.PNG)

2. Sample with command

```
    [Request]
    aws ec2 describe-internet-gateways --region eu-south-1 --profile CLDGRP99
```

```
    [Answer]
    {
        "InternetGateways": [
            {
                "Attachments": [
                    {
                        "State": "available",
                        "VpcId": "vpc-0d0d64ef214e83246"
                    }
                ],
                "InternetGatewayId": "igw-0c5a928f4f4148e81",
                "OwnerId": "709024702237",
                "Tags": [
                    {
                        "Key": "Name",
                        "Value": "IGW-CLD"
                    }
                ]
            }
        ]
    }
```

## Sources

* [AWS - CLI - Developer guide](https://docs.aws.amazon.com/cli/index.html)

---
